﻿using System;

namespace SWII_TP01
{
    class Program
    {
        static void Main(string[] args) {
            Controller.Startup c = new Controller.Startup();
        }
    }
}
